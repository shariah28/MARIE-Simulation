#MARIE SIMULATION CODE using Python | Shariah Allen
#class named MarieSimulator, used to simulate MARIE
class MarieSimulator:
  #function used to initialize the MarieSimulator object
    def __init__(self, memory):
        self.memory = memory #memory is a list of lists, each list is a page
        self.accumulator = 0 #accumulator is the value of the MARIE accumulator
        self.program_counter = 0 #program_counter is the value of the MARIE program counter

  #load function, used to load a program into memory
    def load(self, address):
        self.accumulator = self.memory[address]
#store function, used to store a value in memory
    def store(self, address):
        self.memory[address] = self.accumulator
#add function, used to add a value to the MARIE accumulator
    def add(self, address):
        self.accumulator += self.memory[address]
#subtract function, used to subtract a value from the MARIE accumulator
    def subtract(self, address):
        self.accumulator -= self.memory[address]
#input function, used to input a value into the MARIE accumulator
    def input(self):
        self.accumulator = int(input("Enter a value: "))
#output function, used to output the value of the MARIE accumulator
    def output(self):
        print(self.accumulator)
#jump function, used to jump to a specific location in memory
    def jump(self, address):
        self.program_counter = address
#skipcond function, used to skip the next instruction if the MARIE accumulator is not zero
    def skipcond(self, flag):
        if flag:
            self.program_counter += 1
#jns function, used to jump to a specific location in memory if the MARIE accumulator is not zero
    def jns(self, address):
        if self.accumulator < 0:
            self.program_counter = address
#clear function, used to clear the MARIE accumulator
    def clear(self):
        self.accumulator = 0
#addi function, used to add a value to the MARIE accumulator and store the result in memory
    def addi(self, address):
        self.accumulator += self.memory[address]
#jumpi function, used to jump to a specific location in memory if the MARIE accumulator is zero
    def jumpi(self, address):
        self.program_counter = self.memory[address]
  #this function is used to load the value at the address into the accumulator
    def loadi(self, address):
        self.accumulator = self.memory[self.memory[address]]
  #this function is used to store the value at the accumulator into the address 
    def storei(self, address):
        self.memory[self.memory[address]] = self.accumulator
  #sum_memory function, used to sum the values in memory  
    def sum_memory(self):
        self.accumulator = sum(self.memory)
#Function binary_to_decimal, used to convert a binary number to a decimal number
def binary_to_decimal(binary):
    return int(binary, 2)
#Function decimal_to_binary, used to convert a decimal number to a binary number
def decimal_to_binary(decimal):
    return bin(decimal).replace("0b", "")

# Assuming memory is defined correctly
memory = []  # Provided memory contents
#simulator variable that is used to simulate MARIE
simulator = MarieSimulator(memory)

# Extend the existing code to handle multiple values

#General Message 
message = print('You will be prompted to enter 5 values, all values can be either decimal or binary.') 
print()

def decimalToBinary(n): 

        if(n > 1): 
              # divide with integral result 
              # (discard remainder) 
              decimalToBinary(n//2) 


        print(n%2, end=' ')

def binaryToDecimal(binary):

  decimal, i = 0, 0
  while(binary != 0):
    dec = binary % 10
    decimal = decimal + dec * pow(2, i)
    binary = binary//10
    i += 1
  print(decimal)

# Function to determine if a given input is binary based on the 'b' or 'B' prefix
def is_binary(value):
    return value.startswith('b') or value.startswith('B')

# Convert a string binary number (without 'b' prefix) to a decimal integer
def binary_to_decimal(binary_str):
    return int(binary_str, 2)

# Asking user for 5 values and storing them in memory after conversion if necessary
for i in range(5):
    # Prompt the user to enter the value with 'b' as a prefix if it's binary
    value = input(f"Enter value {i + 1} (prefix 'b' for binary, e.g., b1010 or just 10 for decimal): ")

    if is_binary(value):
        # Remove the 'b' prefix and convert the remaining binary number to decimal, then store it in memory
        decimal_value = binary_to_decimal(value[1:])
        simulator.memory.append(decimal_value)
    else:
        # Directly store the decimal value in memory
        simulator.memory.append(int(value))



'''Where values are loaded and added. Current code takes 5 inputs, which is stored in memory addresses 0-4. To add more values, add an additional simulator.add() statement for the desired amount of inputs'''

simulator.clear()           # Step 1: Clear the accumulator
simulator.load(0)           # Step 2: Load the first input
simulator.add(1)            # Step 3: Add the second input
simulator.add(2)            # Step 4: Add the third input
simulator.add(3)            # Step 5: Add the fourth input
simulator.add(4)            # Step 6: Add the fifth input
simulator.output()          # Step 7: Output the sum 
#END OF MY MARIE SIMULATION USING PYTHON